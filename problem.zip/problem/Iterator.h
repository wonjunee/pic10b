#ifndef Iterator_h
#define Iterator_h

#include <string> 
#include <iostream> 
#include <cassert>
#include "Node.h"
#include "List.h"

using namespace std;

class Node;
class List;
class Iterator { 
public:
	Iterator();
	string get() const;
	void next();
	void previous();
	bool equals(Iterator b) const;
private:
	Node* position; 
	List* container; 
friend class List; 
};

#endif