#ifndef Node_h
#define Node_h

#include <string> 
#include <iostream> 
#include <cassert>
#include "List.h"
#include "Iterator.h"

using namespace std;

class Iterator;
class List;
class Node { 
public:
	Node(string s); 
private:
	string data; 
	Node* previous; 
	Node* next; 
friend class List; 
friend class Iterator; 
};

#endif