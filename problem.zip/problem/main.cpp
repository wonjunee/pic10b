#include <string> 
#include <iostream> 
#include <cassert>
#include "Node.h"
#include "Iterator.h"
#include "List.h"

using namespace std;

int main() { 
	List staff;
	staff.push_back("Tom"); staff.push_back("Dick"); staff.push_back("Harry"); staff.push_back("Juliet");

	Iterator pos; 

	for (pos = staff.begin(); !pos.equals(staff.end()); pos.next()) 
		cout << pos.get() << "\n";

	// reverse the order
	staff.reverse();

	// Print all values
	cout << "\n----- After reverse -----\n";
	for (pos = staff.begin(); !pos.equals(staff.end()); pos.next()) 
		cout << pos.get() << "\n";

}		