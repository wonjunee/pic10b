#include "Node.h"

//----------- Node ------------
Node::Node(string s)
{
	data = s; previous = NULL; next = NULL;
}