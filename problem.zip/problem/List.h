#ifndef List_h
#define List_h

#include <string> 
#include <iostream> 
#include <cassert>
#include "Iterator.h"
#include "Node.h"

using namespace std;

class Iterator;
class Node;
class List { 
public:
	List(); 
	void push_back(string data);
	void insert(Iterator iter, string s); 
	Iterator erase(Iterator iter); 
	Iterator begin(); 
	Iterator end(); 
	void reverse();
private:
	Node* first; 
	Node* last; 
friend class Iterator;
};

#endif